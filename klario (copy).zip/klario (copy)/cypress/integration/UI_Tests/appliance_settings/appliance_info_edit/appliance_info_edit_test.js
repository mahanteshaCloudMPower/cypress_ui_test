describe('Appliance Info Edit page', () =>{
  it('Appliance Info Edit page testing', () =>{
  cy.visit('/login')
  .contains('Login')
//login
cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
cy.get('#signinButton').click()
cy.wait(1000) 

//Appliance Info
cy.get('[class="homeTableBorderBottom"]')
.contains('Info').click()
cy.wait(500)

cy.contains('arrow_back').click()

// //logout
// cy.contains('power_settings_new').click()
//   //.wait(500)
// cy.contains('Yes').click()
})  
})