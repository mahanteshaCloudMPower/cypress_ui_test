describe('Appliance notification page', () =>{
    it('Appliance notification page testing', () =>{
    cy.visit('/login')
    .contains('Login')
//login
 cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
 cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
 cy.get('#signinButton').click()
 cy.wait(1000) 

//Setings
cy.get('[class="homeTableBorderBottom"]')
  .contains('settings').click()
cy.wait(1000)

//Appliance notification
cy.get('[href="#tab-2"]')
  .contains('settings').click()
cy.contains('YES').should('be.visible')
cy.get('[class="vue-slider"]').should('be.visible')

 
// //logout
// cy.contains('power_settings_new').click()
//   //.wait(500)
// cy.contains('Yes').click()
  })  
})
