describe('Appliance softAp_Transactions page', () =>{
  it('Appliance softAp_Transactions page testing', () =>{
  cy.visit('/login')
  .contains('Login')
//login
cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
cy.get('#signinButton').click()
cy.wait(900) 


cy.get('#Search').type('old') 
cy.wait(1000) 
//Setings
cy.get('[class="homeTableBorderBottom"]')
.contains('settings').click()

//Appliance softAp_Transactions
cy.get('[href="#tab-3"]')
.contains('wifi').click().wait(800)

cy.contains('Check Access Point Status')
cy.contains('perm_scan_wifi').click()
cy.contains('Status is')
cy.get('[class="flex text-right xs8"]').find('button').should('have.class', 'ma-0 v-btn v-btn--has-bg theme--light v-size--default primary').contains('Turn').click()


// //logout
// cy.contains('power_settings_new').click()
//   //.wait(500)
// cy.contains('Yes').click()
})  
})