describe('User Access approval page', () =>{
    it('user access approval page testing', () =>{
    cy.visit('/login')
    .contains('Login')
//login
 cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
 cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
 cy.get('#signinButton').click()
 cy.wait(2000) 
 
 cy.get('[id="Approve_Requests"]').click()
 .wait(1000)
 cy.get('[class="v-btn__content"]').contains('Approve').click().wait(1000)
 cy.get('[class="v-btn__content"]').contains('Approve').click()


// //logout
// cy.contains('power_settings_new').click()
//   //.wait(500)
// cy.contains('Yes').click()
  })  
})
