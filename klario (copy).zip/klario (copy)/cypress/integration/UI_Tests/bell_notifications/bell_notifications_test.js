

describe('Bell notifications page', () =>{
    it('Bell notifications testing', () =>{
        cy.visit('/login')
        cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
        cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
        cy.get('#signinButton').click()
   
    cy.wait(500)
    
   
   cy.get('.notification').find('svg').click();
  // cy.contains('Refresh').click()
   // cy.contains('bell').click()
   // cy.get('button[ type="button"]').contains('Yes').click()
})
})


