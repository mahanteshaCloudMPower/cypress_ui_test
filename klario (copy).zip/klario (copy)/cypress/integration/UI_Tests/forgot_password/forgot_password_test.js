describe('Forgot password page', () =>{
    it('Forgot password page testing', () =>{
    cy.visit('/#/forgotPassword')

 cy.get(('input[type="email"]'))
 .should('be.visible').should('be.enabled')
 .type(Cypress.env('email'))

//  cy.get('button[ type="submit"]').click()

    })  
})
