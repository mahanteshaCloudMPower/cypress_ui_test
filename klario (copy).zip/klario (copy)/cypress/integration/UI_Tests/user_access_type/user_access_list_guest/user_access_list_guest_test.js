describe('user access list guest page', () =>{
  it('user access list guest page testing', () =>{
    cy.visit('/login')
    .contains('Login')
    //login
    cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
    cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    cy.get('#signinButton').click()
    cy.wait(1000) 

    cy.contains('User List').click()
    cy.wait(500)

    cy.get('[href="#appliance-data-2"]').click()
    cy.get('[id="Guest_Email"]').type('mahantesha@cloudmpoer.com')
    cy.get('input[id="Valid:_From/To"]').click({ force: true })

    
    //From date
    cy.contains('From Date').click({ force: true })
    cy.get('[id="fromDate_id"]')
    .find('table').find('tbody').find('td')
    .find('button[type="button"]').contains('15').click()
    cy.get('[id="From_Date_Ok"]').click({ force: true })
    cy.wait(1000)

    //To date
    cy.contains('To Date').click({ force: true })
    cy.get('[id="toDate_id"]')
    .find('table').find('tbody').find('td')
    .find('button[type="button"]').contains('20').click()
    cy.get('[id="To_Date_Ok"]').click({force: true})
    cy.wait(200)


    cy.get('[id="Can_invite_one_time_user"]')
    cy.get('[id="Geo_Restriction"]').click({ force: true })
    cy.get('[id="Time_Restriction"]').click({ force: true })
    cy.get('[id="monHours6"]').click({ force: true })
    cy.contains('done').click()

    //  cy.get('[id="Send_Invitation"]').click()
  })
})

