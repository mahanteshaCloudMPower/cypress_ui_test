describe('User access list onetime page', () =>{
  it('User access list onetime test testing', () =>{
    cy.visit('/login')
    .contains('Login')
    //login
    cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
    cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    cy.get('#signinButton').click()
    cy.wait(1000) 


    cy.contains('User List').click()
    cy.wait(500)

    cy.get('[id="Single_User_Name"]').type('mahantesha')
    cy.get('[id="Single_User_Email"]').type('mahantesha@cloudmpower.com')
    cy.get('[name="tel-input-1"]').type(9876543102)
    cy.get('[id="Single_User_Date"]').click()
    cy.contains(28).click()
    cy.get('[id="Single_User_Ok"]').click()
    cy.contains('Specific Time').click()
    cy.wait(1000)

    cy.contains('From time').click({force: true})
    cy.get('[id="From_Time_Id"]')
    cy.get('[class="v-time-picker-clock__inner"]')
    .get('[class="v-time-picker-clock__item"]').contains(7).click().wait(500)
    cy.get('[class="v-time-picker-clock__item"]').get('[style="left: 50%; top: 0%;"]').click()
    cy.get('[class="v-picker__title__btn"]').contains('PM').click()
    cy.get('#From_Time_Ok').click({force:true})

    cy.contains('To time').click({ force: true })
    cy.get('[id="To_Time_Id"]')
    cy.get('[class="v-time-picker-clock__inner"]')
    .get('[class="v-time-picker-clock__item"]').contains(8).click().wait(500)
    cy.get('[class="v-time-picker-clock__item"]').get('[style="left: 6.69873%; top: 75%;"]').click( {force : true, multiple :true })
    cy.get('[class="v-picker__title__btn"]').contains('PM').click({force: true})
    cy.get('#To_Time_Ok').click({force:true})
  

  })
})