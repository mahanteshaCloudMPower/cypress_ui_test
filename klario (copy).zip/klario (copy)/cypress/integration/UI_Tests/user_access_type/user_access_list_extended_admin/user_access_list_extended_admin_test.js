describe('User access list extended admin page', () =>{
  it('User access list extended admin page testing', () =>{
  cy.visit('/login')
  .contains('Login')
  //login
  cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
  cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
  cy.get('#signinButton').click()
  cy.contains('User List').click()

  cy.get('[href="#appliance-data-4"]').click()
  cy.get('[id="userEmailId"]').type('mahantesha@cloudmpoer.com')
  cy.contains('Valid: From/To').click()


  //From date
  cy.contains('From Date').click({ force: true })
  cy.get('[id="From_Date_Picker"]')
  .find('table').find('tbody').find('td')
  .find('button[type="button"]').contains('8').click()
  cy.get('[id="from_OK"]').click({ force: true })


  //To date
  cy.contains('To Date').click({ force: true })
  cy.get('[id="To_Date_Picker"]')
  .find('table').find('tbody').find('td')
  .find('button[type="button"]').contains('10').click()
  cy.get('[id="to_OK"]').click({force: true})
  cy.wait(200)


  cy.get('[id="Geo_fencing"]').click({ force: true })
  cy.get('[id="Time_Restriction"]').click({ force: true })
  cy.get('[id="monHours9"]').click({ force: true })
  cy.contains('done').click()

  //  cy.get('[id="Send_Invitation"]').click()

  cy.get('[id="Search_id"]').type('mahantesha').click().wait(200)
  cy.get('[id="arrow_down_id"]').click()

  cy.get('[id="more_vert"]').click()


  // //Extend button
  cy.get('[id="Extend"]').click()

  cy.get('[id="To_date_id_1"]').click()
  cy.get('[id="To_date_id_2"]')
  .find('table').find('tbody').find('td')
  .find('button[type="button"]').contains('14').click().wait(200)
  cy.get('[id="toDate_ok_id"]').click()
  cy.get('[id="Yes_id"]').contains('YES').click().wait(200)
  //Edit Restriction

  cy.get('[id="Search_id"]').type('mahantesha').click()
  cy.get('[id="arrow_down_id"]').click()
  cy.get('[id="more_vert"]').click()

  cy.get('[id="Edit_Restrictions"]').click()
  cy.get('[id="Geo_Restriction"]').click({force:true})
  cy.get('[id="Time_Restriction"]').click({force:true})
  cy.contains('edit').click()
  cy.get('[id="monHours6"]').click()
  cy.contains('done').click()
  cy.contains('arrow_back').click()


  //Remove Appliance
  cy.get('[id="Search_id"]').type('mahantesha').click()
  cy.get('[id="arrow_down_id"]').click()
  cy.get('[id="more_vert"]').click()
  cy.get('[id="Remove"]').click()
  cy.contains('Are you sure you wish to remove access permissions for')
  //cy.get('[id="revoke_yes"]').click()
  })
})
