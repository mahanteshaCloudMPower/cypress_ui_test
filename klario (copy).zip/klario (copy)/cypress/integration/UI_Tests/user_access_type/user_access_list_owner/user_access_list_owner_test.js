describe('User access list extended admin page', () =>{
  it('User access list extended admin page testing', () =>{
    cy.visit('/login')
    .contains('Login')
    //login
    cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
    cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    cy.get('#signinButton').click()
    cy.wait(1000) 

    cy.contains('User List').click()
    cy.wait(500)

    cy.get('[href="#appliance-data-3"]').click()
    cy.get('[id="Email_id"]').type('mahantesha@cloudmpoer.com')
    cy.contains('Valid: From/To').click()


    //From date
    cy.contains('From Date').click({ force: true })
    cy.get('[id="fromDate_id"]')
    .find('table').find('tbody').find('td')
    .find('button[type="button"]').contains('10').click()
    cy.get('[id="ok_id"]').click({ force: true })
    cy.wait(1000)

    //To date
    cy.contains('To Date').click({ force: true })
    cy.get('[id="toDate_id"]')
    .find('table').find('tbody').find('td')
    .find('button[type="button"]').contains('15').click()
    cy.get('[id="to_ok_id"]').click({force: true})
    cy.wait(200)


    cy.get('[id="isGeofencing_id"]').click({ force: true })
    cy.get('[id="Time-Restriction_id"]').click({ force: true })
    cy.get('[id="monHours8"]').click({ force: true })
    cy.contains('done').click()

    // cy.get('[id="Send_Invitation_id"]').click()
    // cy.get('[id="yes_id"]').click()
    // cy.contains('close').click()
/*
    // cy.get('[id="search_id"]').type('Ppcloud42 42').click()
    cy.get('[id="arrow_down_id"]').click()
    cy.get('[id="more_vert_id"]').click()



    // //Extend button

    // cy.get('[id="Extend"]').click()
    // cy.contains('To Date').click({ force: true }).pause()
    // cy.get('[id="To_Date_Picker"]')
    //   .find('table').find('tbody').find('td')
    //   .find('button[type="button"]').contains('14').click({force:true}).wait(200)
    // cy.get('[id="to_OK"]').click()
    // cy.wait(200)
    // //cy.get('[id="toDate_ok_id"]').click({ force: true })
    // // cy.contains('OK').click({force:true})
    // cy.get('[id="Yes_id"]').contains('YES').click()

    //Edit Restriction
    // cy.get('[id="more_vert_id"]').click()
    cy.get('[id="Edit_Restrictions_id"]').click()
    cy.get('[id="Geo_Restriction"]').click({ force: true })
    cy.get('[id="Time_Restriction"]').click({ force: true })
    cy.contains('edit').click()
    cy.get('[id="monHours6"]').click({ force: true })
    cy.contains('done').click()
    cy.contains('arrow_back').click()



    //Remove Appliance
    cy.get('[id="more_vert_id"]').click()
    cy.get('[id="Remove_id"]').click()
    cy.contains('Are you sure you wish to remove access permissions for')
    cy.get('[id="yes_id"]').click()
    */
  })
   
})

