describe('Developer Settings page', () =>{
    it('Developer Settings page testing', () =>{
      cy.visit('/login')

      cy.get('[href="#/devSettings"]').click()
      cy.contains('Developer settings')
    })
})