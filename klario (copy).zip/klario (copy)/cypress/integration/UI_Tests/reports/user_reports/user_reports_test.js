describe('User report page', () =>{
    it('User Report page testing', () =>{
      cy.visit('/login')
      cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
      cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
      cy.get('#signinButton').click()
      cy.get('#User_Report').click()
      cy.wait(1000)
  
      cy.get('[id="Select_Appliance"]').click({ force: true })
      cy.contains('refresh').click()
      cy.get('[id="Item_User_Name"]').contains('vijeth').click()
      cy.get('#User_Report_Email').click()

//   //logout
//     cy.contains('power_settings_new').click()
//     //.wait(500)
//     cy.contains('Yes').click()
    })
  })
      