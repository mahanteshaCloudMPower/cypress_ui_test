describe('Access report page', () =>{
    it('Access Report page testing', () =>{
      cy.visit('/login')
      cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
      cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
      cy.get('#signinButton').click()
      cy.get('#Access_Report').click()
      cy.wait(1000)

      cy.get('#Get_Report').click()



//   //logout
//     cy.contains('power_settings_new').click()
//     //.wait(500)
//     cy.contains('Yes').click()
    })
  })
      