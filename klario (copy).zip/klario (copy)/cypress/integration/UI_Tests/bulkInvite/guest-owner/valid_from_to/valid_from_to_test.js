describe('Bulk invite page valid From/To', () =>{
it('Guest valid from/to page testing', () =>{
    cy.visit('/login')
    .contains('Login')
//login
 cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
 cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
cy.get('button[ type="submit"]').click()

cy.get('#Search').type('Vijeth') 
cy.wait(2000) 

cy.contains('Invite User').click()
cy.contains('Invite Title ').type('join meeting')
cy.get('[class="v-input__control"]').contains('Select access type')
cy.get('[class="v-input__icon v-input__icon--append"]').click()
cy.contains('Guest').click()
cy.contains('Valid: From/To').click()




//From date
cy.get('[id="From_Date"]').click({ force: true })
cy.get('[id="From_Date_Picker"]')
.find('table').find('tbody').find('td')
.find('button[type="button"]').contains('12').click()
cy.get('[id="From_Date_Ok"]').click({ force: true })
cy.wait(1000)


//To date
cy.get('[id="To_Date"]').click({ force: true })
cy.get('[id="To_Date_Picker"]')
.find('table').find('tbody').find('td')
.find('button[type="button"]').contains('13').click()
cy.get('[id="To_Date_Ok"]').click({force: true})
cy.wait(200)

//Invite User
cy.get('[id="Can_invite_one_time_user"]')
cy.get('[id="Geo_Restrictions"]').click({ force: true })
cy.get('[id="Time_Restriction"]').click({ force: true })
cy.get('[id="monHours6"]').click({ force: true })
cy.contains('done').click()
cy.contains('Next').click()
cy.wait(500)




//File Download
cy.get('button[type="button"]').contains('Download csv').click()
cy.wait(500)
cy.get('#newUserName').should('be.visible').should('be.enabled').click().type('mahan')
cy.get('#newUserEmail').should('be.visible').should('be.enabled').type('mahantesha@cloudmpower.com')
cy.get('button[type="button"]').contains('Add').click()

//File Upload CSV
const yourFixturePath = 'sample.csv';
cy.get('[id="csvFileInput"]').click({force: true}).attachFile(yourFixturePath)
cy.contains('Invite All').click()
cy.get('[id="InviteAllYes"]').contains('Yes').click()



})
})