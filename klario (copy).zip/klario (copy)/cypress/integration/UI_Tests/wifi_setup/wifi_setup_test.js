describe('Wifi setup', () =>{
  it('Wifi setup page testing', () =>{
    cy.visit('/login')
    cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
    cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    cy.get('#signinButton').click()


    cy.contains('perm_scan_wifi').click()
    cy.get('#wifiSSID').type('Vijeth')
    cy.get('#wifiPassword').type(123)
    // cy.get('wpa').click()
    cy.get('#Send').should('be.visible').should('be.enabled')


    //   //logout
    //     cy.contains('power_settings_new').click()
    //     //.wait(500)
    //     cy.contains('Yes').click()
  })
})
      