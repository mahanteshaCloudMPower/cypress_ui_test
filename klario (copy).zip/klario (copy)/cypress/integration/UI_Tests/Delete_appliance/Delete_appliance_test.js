describe('Delete Appliance page', () =>{
    it('Delete Appliance testing', () =>{
    cy.visit('/login')
    .contains('Login')
  //login
  cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
  cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
  cy.get('#signinButton').click()
  cy.wait(1000) 

  //search
  cy.get('#Search').type('old') 
  cy.wait(1000) 

  //Setings
  cy.get('[class="homeTableBorderBottom"]')
  .contains('settings').click()
  
  //Delete Appliance
  cy.get('[id="delete_forever_id"]').click()
  cy.wait(500)
  cy.get('[id="Delete_Anyway_id"]').click()
  cy.get('[id="Type_password_id"]').type('123')
  cy.get('[id="Delete_id"]').click()

  
//   //logout
//   cy.contains('power_settings_new').click()
//   //.wait(500)
//   cy.contains('Yes').click()
  })  
  })
  