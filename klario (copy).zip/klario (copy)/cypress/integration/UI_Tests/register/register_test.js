describe('Register page', () =>{
    it('Register page testing', () =>{
    cy.visit('/#/register')
    .contains('New user')
    .url().should('include', '/register')
//register
 cy.get('[id="input-18"]').should('be.visible').should('be.enabled').type('vijeth')
 cy.get('[id="input-21"]').should('be.visible').should('be.enabled').type('v')
 cy.get('[id="input-24"]').should('be.visible').should('be.enabled').type('cloudmpower')
 cy.get('[id="input-27"]').should('be.visible').should('be.enabled').type('vijeth@cloudmpower.com')
 cy.get('[id="input-31"]').should('be.visible').should('be.enabled').type('123')
 cy.get('[id="input-35"]').should('be.visible').should('be.enabled').type('123')
 cy.get('input[type="tel"]').should('be.visible').should('be.enabled').type('8553791321')
//  cy.get('button[ type="submit"]').click()

    })  
})
