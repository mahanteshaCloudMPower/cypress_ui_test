describe('Add Appliance page', () =>{
    it('Add Appliance page testing', () =>{
      cy.visit('/login')
      cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
      cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
      cy.get('#signinButton').click()
  
      cy.wait(2000)
      cy.get('#Add_Appliance').click()
      cy.get('#addAppInput').should('be.visible').should('be.enabled').type('1994')
      cy.get('#add').click()
      cy.wait(2000)


      //Geo restriction
      cy.get('[id="contentId"]').find('[id="setApplLocGMap"]').click(150, 150)
      cy.get('[id="Save_id"]').click()
      
      
      //Slider
      cy.get('[id="geoFenceSlider_id"]')
      cy.get('[id="next_id"]').click()

      //Time restriction
      cy.get('[id="scheduleTable"]').click()
      cy.get('[id="Save_id"]').click()
      cy.get('[id="Yes_id"]').click()

      //Wifi Permission
      cy.get('#wifiSSID').type('Hegdeblr')
      cy.get('#wifiPassword').type('Hegde#123')
    // cy.get('wpa').click()
      cy.get('#Send').should('be.visible').should('be.enabled').click()
      cy.wait(60000)
      cy.get('[id="Continue_id"]').click()


    // //logout
    // cy.contains('power_settings_new').click()
    // //.wait(500)
    // cy.contains('Yes').click()
    })
  })
      