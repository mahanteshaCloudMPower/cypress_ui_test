describe('Privacy policy page', () =>{
    it('privacy policy page testing', () =>{
      cy.visit('/login')
      cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
      cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
      cy.get('#signinButton').click()
      cy.get('#Privacy_Policy').click()
      cy.wait(2000)
    
    //logout
    cy.contains('power_settings_new').click()
    //.wait(500)
    cy.contains('Yes').click()  
    })
  })
      