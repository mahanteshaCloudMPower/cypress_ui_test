


describe('Appliance location', () => {
    it('testing', () => {
            cy.visit('/login')
            .contains('Login')
            //login
            cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
            cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
            cy.get('#signinButton').click()
            cy.wait(2000)
            //Setings
            cy.get('[id="Search"]').should('be.visible').should('be.enabled').type('old')
            cy.get('[class="homeTableBorderBottom"]')
            .contains('settings').click()
            cy.wait(500)
            //geo alert
            cy.get('[href="#tab-4"]').find('i').contains('location_on').click({ multiple: true })
            // cy.contains('set Alert Location').click()


            cy.wait(1000)

            // cy.wait(2000)
            // cy.get('[id="goToApplLoc"]').click()
          //  cy.get('[id="goToApplLoc"]').click({force:true},{multiple:true})


          //   cy.get('[id="contentId"]').find('[id="changeAlertLocGMap"]').click(150, 150)

            

            // cy.get('id="SaveAlert"').click()
            // cy.get('button[type="button"]').contains('close').click()


            //

            cy.get('[id="tab-4"]').find('img').last().click()
            cy.wait(1000)
            cy.get('[id="contentId"]').find('[id="changeApplLocGMap"]').click(130, 190)
            cy.get('[id="contentId"]').find('button[type="button"]').contains('Save')
           
            })
})