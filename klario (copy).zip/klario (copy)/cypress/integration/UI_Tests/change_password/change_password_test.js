describe('Change Password page', () =>{
  it('Change Password page testing', () =>{
    cy.visit('/login')
    cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
    cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    cy.get('#signinButton').click()
    cy.get('#Settings').click()


    cy.contains('OFF').click()
    cy.contains('arrow_forward').click()
    cy.wait(500)
    cy.get('#NEW_PASSWORD').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    //cy.contains('visibility').click()
    cy.get('#CONFIRM_PASSWORD').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
    //cy.contains('Change Password').click()
    cy.wait(2000)

    
  // //logout
  // cy.contains('power_settings_new').click()
  // //.wait(500)
  // cy.contains('Yes').click()  
  })
})
