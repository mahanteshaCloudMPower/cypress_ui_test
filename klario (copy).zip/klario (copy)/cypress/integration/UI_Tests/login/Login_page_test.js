describe('Login page', () =>{
    it('Login page testing', () =>{
    cy.visit('/login')
    .contains('Login')
//login
 cy.get('[id="emailIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('email'))
 cy.get('[id="pwdIdInput"]').should('be.visible').should('be.enabled').type(Cypress.env('password1'))
 cy.get('#signinButton').click()
 cy.wait(2000) 
 

cy.get('#Search').type('Attack') 
cy.wait(2000) 


//logout
cy.contains('power_settings_new').click()
  //.wait(500)
cy.contains('Yes').click()
  })  
})
